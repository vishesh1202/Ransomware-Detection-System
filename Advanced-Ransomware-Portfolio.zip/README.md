# Advanced Ransomware Detection Portfolio Project

Portfolio-grade educational SOC/EDR simulation.
